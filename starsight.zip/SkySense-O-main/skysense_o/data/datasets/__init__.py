import sys
from . import (
    register_isaid,
    register_potsdam,
    register_samrs_fast,
    register_samrs_sota,
    register_samrs_sior,
    register_uavid,
    register_floodnet,
    register_loveda,
    register_vaihingen,
    register_oem,
    register_skysa_graph,
)
